//
//  ViewController.swift
//  AudioPlayer
//
//  Created by agilemac-9 on 5/26/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    private var audioPlayer: AVAudioPlayer?

    @IBOutlet var sliderval: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let audioPath = Bundle.main.path(forResource: "Selfish", ofType: "mp3")
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
        }
        catch {
            print("Something bad happened. Try catching specific errors to narrow things down")
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func slidermov(_ sender: UISlider)
    {
        audioPlayer?.volume = sliderval.value
        print("Volume: \(audioPlayer?.volume ?? 0.0)")
    }
    
    @IBAction func ActionPlay(_ sender: UIButton) {
        audioPlayer?.play()
    }

    @IBAction func ActionPause(_ sender: UIButton) {
        audioPlayer?.pause()
    }
    
    @IBAction func ActionStop(_ sender: UIButton) {
        audioPlayer?.stop()
        print("Current Time: \(audioPlayer?.currentTime ?? 0.0)")
        audioPlayer?.currentTime = 0
    }
}

